#ifndef FUNCTIONS_H 
#define FUNCTIONS_H

extern const double a ;
extern const double b ;


double f (double, double) ;
double g_1 (double) ;
double g_2 (double) ;
double g_3 (double) ;
double g_4 (double) ;

double solution (double, double) ;

#endif
